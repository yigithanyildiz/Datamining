import torch
import random
from torch_geometric.nn import GCNConv
import torch.nn.functional as F
import numpy as np

# =====================
# Load graph
# =====================
device = torch.device("cpu")
print("Using device:", device)

data = torch.load("amazon_office_graph.pt", weights_only=False)
data = data.to(device)

num_nodes = data.num_nodes

# =====================
# GCN Model
# =====================
class GCN(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.conv1 = GCNConv(2, 16)
        self.conv2 = GCNConv(16, 2)

    def forward(self, x, edge_index):
        x = self.conv1(x, edge_index)
        x = F.relu(x)
        x = self.conv2(x, edge_index)
        return x

# =====================
# Train / Eval
# =====================
def train_and_eval(edge_index, epochs=50):
    model = GCN().to(device)
    optimizer = torch.optim.Adam(model.parameters(), lr=0.01)

    user_mask = data.y != -1
    user_indices = user_mask.nonzero(as_tuple=True)[0]

    perm = torch.randperm(len(user_indices))
    train_idx = user_indices[perm[:int(0.8 * len(perm))]]
    test_idx = user_indices[perm[int(0.8 * len(perm)):]]

    for _ in range(epochs):
        model.train()
        optimizer.zero_grad()
        out = model(data.x, edge_index)
        loss = F.cross_entropy(out[train_idx], data.y[train_idx])
        loss.backward()
        optimizer.step()

    model.eval()
    with torch.no_grad():
        out = model(data.x, edge_index)
        pred = out.argmax(dim=1)
        acc = (pred[test_idx] == data.y[test_idx]).float().mean().item()

    return acc

# =====================
# 1️⃣ Original Graph
# =====================
acc_original = train_and_eval(data.edge_index)
print(f"Original Graph Accuracy: {acc_original:.4f}")

# =====================
# 2️⃣ Randomized Graph
# =====================
edge_index = data.edge_index.clone()
num_edges = edge_index.size(1)

random_src = torch.randint(0, num_nodes, (num_edges,))
random_dst = torch.randint(0, num_nodes, (num_edges,))
random_edge_index = torch.stack([random_src, random_dst]).to(device)

acc_random = train_and_eval(random_edge_index)
print(f"Randomized Graph Accuracy: {acc_random:.4f}")

# =====================
# Summary
# =====================
print("\n=== SUMMARY ===")
print(f"Original Accuracy   : {acc_original:.4f}")
print(f"Random Graph Accuracy: {acc_random:.4f}")
